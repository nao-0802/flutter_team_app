package com.example.flutter_temp_fix

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
